package com.java.dao;

import java.util.List;

import com.java.entities.Contact;

public interface ContactDAO {
	public void insertContact(Contact contact);
	public Contact selectContact(String aadaharNumber);
	public List<Contact> selectContacts();
	//public void updateContact(Contact contact);
	
}