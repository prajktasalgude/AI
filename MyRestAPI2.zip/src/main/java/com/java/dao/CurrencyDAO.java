package com.java.dao;

import java.util.List;

import com.java.entities.Currency;

public interface CurrencyDAO {

	//CRUD
	
	List<Currency> getAllCurrencies();
	Currency getCurrency(int cid);
	
	void insertCurrency(Currency curr);
	void updateCurrency(Currency curr);
	void deleteCurrency(int id);
	
	
}
