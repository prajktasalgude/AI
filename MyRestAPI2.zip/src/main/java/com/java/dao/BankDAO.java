package com.java.dao;

import java.util.List;

import com.java.entities.Bank;

public interface BankDAO {
	void createBank(Bank bank);
	Bank selectBank(String accountNumber);
	List<Bank> selectBanks();
	void updateBank(Bank bank);
}
