package com.java.entities;

import java.util.Date;

public class Students {
	//data members
	//Register()
	//Login()
	//ApplyForScholarship()
	
	private String aadharNumber;
	private String studentName;
	private Date DOB;
	private String gender;
	private String instituteCode;
	private String accountNumber;
	private String password;
	public String getAadharNumber() {
		return aadharNumber;
	}
	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getInstituteCode() {
		return instituteCode;
	}
	public void setInstituteCode(String instituteCode) {
		this.instituteCode = instituteCode;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Students [aadharNumber=" + aadharNumber + ", studentName=" + studentName + ", DOB=" + DOB + ", gender="
				+ gender + ", instituteCode=" + instituteCode + ", accountNumber=" + accountNumber + ", password="
				+ password + "]";
	}
	
}