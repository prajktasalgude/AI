package com.java.service;

import java.util.List;

import com.java.entities.Institute;

public interface InstituteService {
	void createInstituteService(Institute institute);
	Institute findInstituteService(String instituteCode);
	List<Institute> findInstitutesService();
	void modifyInstituteService(Institute institute);
	void removeInstituteService(String instituteCode);
}
