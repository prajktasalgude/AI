package com.java.service;

import java.util.List;

import com.java.entities.Scholarship;

public interface ScholarshipService {
	void createScholarshipService(Scholarship sch);
	Scholarship findScholarshipService(String aadharNumber);
	List<Scholarship> findScholarshipsService();
	void modifyScholarshipService(Scholarship sch);
	void removeScholarshipService(String aadhartNumber);
}
