package com.java.service;

import java.util.List;

import com.java.exceptions.CurrencyAlreadyExistsException;
import com.java.exceptions.CurrencyNotFoundException;
import com.java.entities.Currency;

public interface CurrencyService {

	List<Currency> getAllCurrenciesService() ;
	Currency getCurrency(int id) ;
	
	void addCurrencyService(Currency curr) throws CurrencyAlreadyExistsException;
	void modifyCurrencyService(Currency curr) throws CurrencyNotFoundException;
	void removeCurrencyService(int id) throws CurrencyNotFoundException;
	public double calculateCurrencyService(String s, String t, float amt) throws CurrencyNotFoundException;
	


	
}
